package com.example.stacked_images_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
